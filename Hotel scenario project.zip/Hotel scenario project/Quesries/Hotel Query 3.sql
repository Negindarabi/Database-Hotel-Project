select COUNT(*) as 'free rooms count' from Rooms
 where Room_ID not in 
 (select Room_ID from Reservation where Date_in<='1391-01-01' and Date_out>'1390-01-01')