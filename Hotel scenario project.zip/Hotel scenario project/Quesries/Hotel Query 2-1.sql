select COUNT(*) as count from Rooms_Guests 
inner join Guests on Rooms_Guests.Guest_ID=Guests.Guest_ID 
and Guests.Nationality!='local'