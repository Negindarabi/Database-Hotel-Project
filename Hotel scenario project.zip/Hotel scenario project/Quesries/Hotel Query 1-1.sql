select * from Guests 
where Guest_ID in ( select Guest_ID from Reservation where Date_in='1391-01-01') 