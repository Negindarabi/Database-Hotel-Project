select count(Guest_ID) as count from Rooms_Guests 
where Guest_ID in(select Guest_ID from Guests where Nationality!='local')