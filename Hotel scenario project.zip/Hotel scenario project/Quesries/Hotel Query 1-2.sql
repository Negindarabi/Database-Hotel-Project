select * from Guests 
where Guest_ID in ( select Guest_ID from Rooms_Guests where Date='1391-01-01') 